﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Javapad
{
    public partial class Javapad : Form
    {
        public Javapad()
        {
            InitializeComponent();
        }

        private void editorBox_Click(object sender, EventArgs e)
        {

        }

        private void editorBox_FontChanged(object sender, EventArgs e)
        {

        }

        private void editorBox_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void editorBox_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void editorBox_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void editorBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void editorBox_VScroll(object sender, EventArgs e)
        {

        }
        private bool expand = false;
        private int MIN_EXPAND = 60;
        private int MAX_EXPAND = 600;
        private void outputExpander_MouseDown(object sender, MouseEventArgs e)
        {
            expand = true;
            //outputExpander.Location = new Point(outputExpander.Location.X, outputExpander.Location.Y - 10);
            //Console.WriteLine(outputExpander.Location.Y);
        }

        private void outputExpander_MouseMove(object sender, MouseEventArgs e)
        {
            //Console.WriteLine("info: "+(this.Height - MIN_EXPAND) + "y: " + outputExpander.Location.Y);
            if (expand)
            {
                /*if (outputExpander.Location.Y > this.Height - MIN_EXPAND)
                {
                    Console.WriteLine("below mini");
                    outputExpander.Location = new Point(0, this.Height - MIN_EXPAND + bottomPanel.Height + 2);
                }*/
                
                //Console.WriteLine(":"+outputExpander.Location.Y);
                // move the expander up and down
                Point getExPos = outputExpander.Location;
                outputExpander.Location = new Point(0, getExPos.Y + e.Y);
                // change the height of the mainPanel
                mainPanel.Height = outputExpander.Location.Y;
                // change the height of the outputPanel
                outputPanel.Height = this.Height - mainPanel.Height - 60; // 60 to make sure the bottomPanel is exposed.
                Console.WriteLine("formH: " + this.Height + " | mainH: " + mainPanel.Height + " | outputheight: " + outputPanel.Height);
                // change the location of the bottomPanel as well
                outputPanel.Location = new Point(0, outputExpander.Location.Y);
                Console.WriteLine("pos: " + (outputExpander.Location.Y));
            }
        }

        private void outputExpander_MouseUp(object sender, MouseEventArgs e)
        {
            expand = false;
            if (outputExpander.Location.Y > this.Height - MIN_EXPAND)
                outputExpander.Location = new Point(0, this.Height - MIN_EXPAND);
            if (outputExpander.Location.Y < 0)
            {
                outputExpander.Location = new Point(0, 10);
                outputPanel.Location = new Point(0, 12);
                outputPanel.Height -= 12;
            }
        }

        private void compilerWorker_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void compilerWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }

        private void runWorker_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void runWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }
    }
}
