﻿namespace Javapad
{
    partial class Javapad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Javapad));
            this.mainPanel = new System.Windows.Forms.Panel();
            this.outputPanel = new System.Windows.Forms.Panel();
            this.bottomPanel = new System.Windows.Forms.Panel();
            this.outputExpander = new System.Windows.Forms.Panel();
            this.posLabel = new System.Windows.Forms.Label();
            this.jdkLabel = new System.Windows.Forms.Label();
            this.lineBox = new System.Windows.Forms.RichTextBox();
            this.editorBox = new System.Windows.Forms.RichTextBox();
            this.lblOutput = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.outputBodyPanel = new System.Windows.Forms.Panel();
            this.compilerWorker = new System.ComponentModel.BackgroundWorker();
            this.runWorker = new System.ComponentModel.BackgroundWorker();
            this.mainPanel.SuspendLayout();
            this.outputPanel.SuspendLayout();
            this.bottomPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.mainPanel.Controls.Add(this.editorBox);
            this.mainPanel.Controls.Add(this.lineBox);
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(588, 385);
            this.mainPanel.TabIndex = 0;
            // 
            // outputPanel
            // 
            this.outputPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.outputPanel.Controls.Add(this.outputBodyPanel);
            this.outputPanel.Controls.Add(this.label1);
            this.outputPanel.Controls.Add(this.lblOutput);
            this.outputPanel.Location = new System.Drawing.Point(0, 387);
            this.outputPanel.Name = "outputPanel";
            this.outputPanel.Size = new System.Drawing.Size(588, 90);
            this.outputPanel.TabIndex = 1;
            // 
            // bottomPanel
            // 
            this.bottomPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(33)))), ((int)(((byte)(122)))));
            this.bottomPanel.Controls.Add(this.jdkLabel);
            this.bottomPanel.Controls.Add(this.posLabel);
            this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomPanel.Location = new System.Drawing.Point(0, 477);
            this.bottomPanel.Name = "bottomPanel";
            this.bottomPanel.Size = new System.Drawing.Size(589, 20);
            this.bottomPanel.TabIndex = 2;
            // 
            // outputExpander
            // 
            this.outputExpander.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputExpander.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.outputExpander.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.outputExpander.Location = new System.Drawing.Point(0, 385);
            this.outputExpander.Name = "outputExpander";
            this.outputExpander.Size = new System.Drawing.Size(588, 2);
            this.outputExpander.TabIndex = 0;
            this.outputExpander.MouseDown += new System.Windows.Forms.MouseEventHandler(this.outputExpander_MouseDown);
            this.outputExpander.MouseMove += new System.Windows.Forms.MouseEventHandler(this.outputExpander_MouseMove);
            this.outputExpander.MouseUp += new System.Windows.Forms.MouseEventHandler(this.outputExpander_MouseUp);
            // 
            // posLabel
            // 
            this.posLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.posLabel.AutoSize = true;
            this.posLabel.ForeColor = System.Drawing.Color.White;
            this.posLabel.Location = new System.Drawing.Point(256, 3);
            this.posLabel.Name = "posLabel";
            this.posLabel.Size = new System.Drawing.Size(91, 13);
            this.posLabel.TabIndex = 0;
            this.posLabel.Text = "Ln 1, Col 1, Pos 1";
            // 
            // jdkLabel
            // 
            this.jdkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.jdkLabel.AutoSize = true;
            this.jdkLabel.ForeColor = System.Drawing.Color.White;
            this.jdkLabel.Location = new System.Drawing.Point(13, 3);
            this.jdkLabel.Name = "jdkLabel";
            this.jdkLabel.Size = new System.Drawing.Size(72, 13);
            this.jdkLabel.TabIndex = 1;
            this.jdkLabel.Text = "jdk: not found";
            // 
            // lineBox
            // 
            this.lineBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lineBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lineBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lineBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lineBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.lineBox.Location = new System.Drawing.Point(0, 0);
            this.lineBox.Margin = new System.Windows.Forms.Padding(10);
            this.lineBox.Name = "lineBox";
            this.lineBox.ReadOnly = true;
            this.lineBox.Size = new System.Drawing.Size(45, 385);
            this.lineBox.TabIndex = 1;
            this.lineBox.Text = "";
            // 
            // editorBox
            // 
            this.editorBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.editorBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.editorBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.editorBox.Font = new System.Drawing.Font("Courier New", 14.25F);
            this.editorBox.ForeColor = System.Drawing.Color.White;
            this.editorBox.Location = new System.Drawing.Point(45, 0);
            this.editorBox.Name = "editorBox";
            this.editorBox.Size = new System.Drawing.Size(544, 384);
            this.editorBox.TabIndex = 0;
            this.editorBox.Text = "";
            this.editorBox.SelectionChanged += new System.EventHandler(this.editorBox_SelectionChanged);
            this.editorBox.VScroll += new System.EventHandler(this.editorBox_VScroll);
            this.editorBox.Click += new System.EventHandler(this.editorBox_Click);
            this.editorBox.FontChanged += new System.EventHandler(this.editorBox_FontChanged);
            this.editorBox.TextChanged += new System.EventHandler(this.editorBox_TextChanged);
            this.editorBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.editorBox_KeyDown);
            this.editorBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.editorBox_KeyUp);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Font = new System.Drawing.Font("Courier Std", 8.25F, System.Drawing.FontStyle.Underline);
            this.lblOutput.ForeColor = System.Drawing.Color.White;
            this.lblOutput.Location = new System.Drawing.Point(15, 6);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(47, 12);
            this.lblOutput.TabIndex = 1;
            this.lblOutput.Text = "OUTPUT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier Std", 8.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(82, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "PROBLEMS";
            // 
            // outputBodyPanel
            // 
            this.outputBodyPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputBodyPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.outputBodyPanel.Location = new System.Drawing.Point(4, 22);
            this.outputBodyPanel.Name = "outputBodyPanel";
            this.outputBodyPanel.Size = new System.Drawing.Size(581, 62);
            this.outputBodyPanel.TabIndex = 3;
            // 
            // compilerWorker
            // 
            this.compilerWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.compilerWorker_DoWork);
            this.compilerWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.compilerWorker_RunWorkerCompleted);
            // 
            // runWorker
            // 
            this.runWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.runWorker_DoWork);
            this.runWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.runWorker_RunWorkerCompleted);
            // 
            // Javapad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(589, 497);
            this.Controls.Add(this.bottomPanel);
            this.Controls.Add(this.outputExpander);
            this.Controls.Add(this.outputPanel);
            this.Controls.Add(this.mainPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Javapad";
            this.Text = "Javapad";
            this.mainPanel.ResumeLayout(false);
            this.outputPanel.ResumeLayout(false);
            this.outputPanel.PerformLayout();
            this.bottomPanel.ResumeLayout(false);
            this.bottomPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel outputPanel;
        private System.Windows.Forms.Panel bottomPanel;
        private System.Windows.Forms.Panel outputExpander;
        private System.Windows.Forms.Label jdkLabel;
        private System.Windows.Forms.Label posLabel;
        private System.Windows.Forms.RichTextBox editorBox;
        private System.Windows.Forms.RichTextBox lineBox;
        private System.Windows.Forms.Panel outputBodyPanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblOutput;
        private System.ComponentModel.BackgroundWorker compilerWorker;
        private System.ComponentModel.BackgroundWorker runWorker;
    }
}

